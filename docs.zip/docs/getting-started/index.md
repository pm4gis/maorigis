---
title: Getting started
sidebar_position: 2
---

# Getting started

This section helps you choose tools and start basic workflows.

## Start here

- [Tools overview](/docs/getting-started/tools)
- [QGIS](/docs/getting-started/qgis)
