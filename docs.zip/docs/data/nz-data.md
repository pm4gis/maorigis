---

title: NZ data sources

sidebar\_position: 1

---



\# NZ data sources



This page exists to support links from the homepage.



Add your national and local data sources here (LINZ Data Service, Stats NZ, councils, regional datasets, and other useful sources).



